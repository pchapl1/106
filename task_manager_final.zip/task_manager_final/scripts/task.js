class Task{
    constructor(title, important, dueDate, contact, location, description, color){
        this.title = title;
        this.important = important;
        this.dueDate = dueDate;
        this.contact = contact;
        this.location = location;
        this.description = description;
        this.color = color;
        this.name = 'pchap' //pk
    }
}